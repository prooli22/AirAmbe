﻿//Nom: Vincent Désilets
//Date: 2016-12-12
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirAmbe
{
    /// <summary>
    /// Enum qui fonctionne avec le generateur
    /// </summary>
    public enum Etat
    {
        Attente,
        Assigne,
        Decollage,
        Atterrissage,
        Critique,
        Echoue
    }
}
